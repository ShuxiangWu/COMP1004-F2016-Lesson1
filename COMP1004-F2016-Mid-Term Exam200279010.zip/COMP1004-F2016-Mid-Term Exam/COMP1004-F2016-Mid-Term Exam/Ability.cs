﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace COMP1004_F2016_Mid_Term_Exam
{
    public enum Ability
    {
        Strength,
        Dexterity,
        Constitution,
        Intelligence,
        Wisdom,
        Charisma
    }
}